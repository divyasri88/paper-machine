clc;
clear;
close all;

% Define Laplace variable
s = tf('s');

% Gst(s) Transfer Function
num_gst = [5.421 1.693 -7.22]; 
den_gst = [7500 17500 10000]; 
Gst = tf(num_gst, den_gst);

% FOPID Parameters 
fopid_ALO_vals = [11.0, 6.5, 3.2, 0.85, 0.9];    
fopid_MFO_vals = [13.2, 7.8, 4.0, 0.83, 0.88];   
fopid_EHO_vals = [12.0, 7.0, 3.5, 0.84, 0.89];   
fopid_JSO_vals = [8.2, 4.4, 2.2, 0.86, 0.87];    
wL = 1e-3;
wH = 1e2;
N = 5;
C_FOPID_ALO = fopid_controller(fopid_ALO_vals, wL, wH, N);
C_FOPID_MFO = fopid_controller(fopid_MFO_vals, wL, wH, N);
C_FOPID_EHO = fopid_controller(fopid_EHO_vals, wL, wH, N);
C_FOPID_JSO = fopid_controller(fopid_JSO_vals, wL, wH, N);

% Sensitivity Functions for Gst(s)
S_FOPID_ALO = feedback(1, C_FOPID_ALO * Gst);
S_FOPID_MFO = feedback(1, C_FOPID_MFO * Gst);
S_FOPID_EHO = feedback(1, C_FOPID_EHO * Gst);
S_FOPID_JSO = feedback(1, C_FOPID_JSO * Gst);

% Frequency response
w = logspace(-2, 2, 1000);
[mag_ALO, ~] = bode(S_FOPID_ALO, w);  mag_ALO = squeeze(mag_ALO);
[mag_MFO, ~] = bode(S_FOPID_MFO, w);  mag_MFO = squeeze(mag_MFO);
[mag_EHO, ~] = bode(S_FOPID_EHO, w);  mag_EHO = squeeze(mag_EHO);
[mag_JSO, ~] = bode(S_FOPID_JSO, w);  mag_JSO = squeeze(mag_JSO);

% Plot
figure;
semilogx(w, 20*log10(mag_ALO), 'g', ...
         w, 20*log10(mag_MFO), 'r', ...
         w, 20*log10(mag_EHO), 'm', ...
         w, 20*log10(mag_JSO), 'b', 'LineWidth', 1.5);
legend('ALO', 'MFO', 'EHO', 'JSO', 'Location', 'Best');
xlabel('Frequency (rad/s)');
ylabel('Magnitude (dB)');
title('Sensitivity Function for Gst(s) - BODE DIAGRAM');
ylim([0 10]);
grid on;

% ------------------------------ Functions ------------------------------ 
function C = fopid_controller(params, wL, wH, N)
    Kp = params(1); Ki = params(2); Kd = params(3);
    lambda = params(4); mu = params(5);
    s_lambda = oustaloup(wL, wH, N, -lambda);  % Integral
    s_mu = oustaloup(wL, wH, N, mu);           % Derivative
    C = Kp + Ki * s_lambda + Kd * s_mu;
end

function G = oustaloup(wL, wH, N, alpha)
    K = wH^alpha;
    zeta = zeros(1, 2*N+1); rho = zeros(1, 2*N+1);
    for n = -N:N
        wn = sqrt(wL * wH) * (wH/wL)^((n + 0.5)/(2*N + 1));
        zeta(n + N + 1) = wn;
        rho(n + N + 1) = wn;
    end
    num = K * poly(zeta);
    den = poly(rho);
    G = tf(num, den);
end
