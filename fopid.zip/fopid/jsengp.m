clc;
clear;
close all;

% Define Laplace variable
s = tf('s');

% Paper Machine Transfer Function Gp(s)
num_gp = [-0.288 0.8825 0.5452];
den_gp = [1.247 5.365 4.39 1];
Gp = tf(num_gp, den_gp);

% FOPID Controller Parameters 
fopid_ALO_vals = [0.65, 0.35, 0.1, 0.95, 0.85];
fopid_MFO_vals = [0.55, 0.3, 0.1, 0.9, 0.8];
fopid_EHO_vals = [0.9, 0.35, 0.12, 1.05, 0.55];
fopid_JSO_vals = [0.5, 0.2, 0.05, 1.15, 0.5];  
wL = 1e-3;
wH = 1e2;
N = 5;
C_FOPID_ALO = fopid_controller(fopid_ALO_vals, wL, wH, N);
C_FOPID_MFO = fopid_controller(fopid_MFO_vals, wL, wH, N);
C_FOPID_EHO = fopid_controller(fopid_EHO_vals, wL, wH, N);
C_FOPID_JSO = fopid_controller(fopid_JSO_vals, wL, wH, N);

% Sensitivity Functions: S = 1 / (1 + C(s)*Gp(s))
S_FOPID_ALO = feedback(1, C_FOPID_ALO * Gp);
S_FOPID_MFO = feedback(1, C_FOPID_MFO * Gp);
S_FOPID_EHO = feedback(1, C_FOPID_EHO * Gp);
S_FOPID_JSO = feedback(1, C_FOPID_JSO * Gp);
% Frequency range for Bode plot
w = logspace(-2, 2, 1000);
%  Bode magnitude
[mag_ALO, ~] = bode(S_FOPID_ALO, w);  mag_ALO = squeeze(mag_ALO);
[mag_MFO, ~] = bode(S_FOPID_MFO, w);  mag_MFO = squeeze(mag_MFO);
[mag_EHO, ~] = bode(S_FOPID_EHO, w);  mag_EHO = squeeze(mag_EHO);
[mag_JSO, ~] = bode(S_FOPID_JSO, w);  mag_JSO = squeeze(mag_JSO);
% Sensitivity Function 
figure;
semilogx(w, 20*log10(mag_ALO), 'g', ...
         w, 20*log10(mag_MFO), 'r', ...
         w, 20*log10(mag_EHO), 'm', ...
         w, 20*log10(mag_JSO), 'b', 'LineWidth', 1.5);
legend('ALO', 'MFO', 'EHO', 'JSO-PROPOSED', 'Location', 'Best');
xlabel('Frequency (rad/s)');
ylabel('Magnitude (dB)');
title('Sensitivity Function - BODE DIAGRAM');
ylim([0 10]); 
grid on;

% ------------------------------  Functions ------------------------------
function C = fopid_controller(params, wL, wH, N)
    Kp = params(1);
    Ki = params(2);
    Kd = params(3);
    lambda = params(4);
    mu = params(5);
    s_lambda = oustaloup(wL, wH, N, -lambda);  % Integral
    s_mu = oustaloup(wL, wH, N, mu);           % Derivative
    C = Kp + Ki * s_lambda + Kd * s_mu;
end

function G = oustaloup(wL, wH, N, alpha)
    K = wH^alpha;
    zeta = zeros(1, 2*N+1);
    rho = zeros(1, 2*N+1);
    for n = -N:N
        wn = sqrt(wL * wH) * (wH/wL)^((n + 0.5)/(2*N + 1));
        zeta(n + N + 1) = wn;
        rho(n + N + 1) = wn;
    end
    num = K * poly(zeta);
    den = poly(rho);
    G = tf(num, den);
end


