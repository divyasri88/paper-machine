clc;
clear;
close all;

% Time setup
t = 0:0.01:10;  % 0 to 10 seconds, step 0.01
n = length(t);

% error signals 
e_PI = exp(-0.5*t).*sin(2*t);              
e_PID = exp(-0.6*t).*sin(2*t + 0.2);        
e_FOPID = exp(-0.7*t).*sin(2*t - 0.1);      

% Performance Indices
IAE_PI = cumtrapz(t, abs(e_PI));
IAE_PID = cumtrapz(t, abs(e_PID));
IAE_FOPID = cumtrapz(t, abs(e_FOPID));

ISE_PI = cumtrapz(t, e_PI.^2);
ISE_PID = cumtrapz(t, e_PID.^2);
ISE_FOPID = cumtrapz(t, e_FOPID.^2);

ITAE_PI = cumtrapz(t, t .* abs(e_PI));
ITAE_PID = cumtrapz(t, t .* abs(e_PID));
ITAE_FOPID = cumtrapz(t, t .* abs(e_FOPID));

% Colors
color_PI = [1 0 1];     % Magenta
color_PID = [0 1 0];    % Green
color_FOPID = [0 0 1];  % Blue

figure;

% ----------------- IAE Plot -----------------
subplot(3,1,1);
plot(t, IAE_PI, 'Color', color_PI, 'LineWidth', 1.8); hold on;
plot(t, IAE_PID, 'Color', color_PID, 'LineWidth', 1.8);
plot(t, IAE_FOPID, 'Color', color_FOPID, 'LineWidth', 1.8);
xlabel('Time (Sec)');
ylabel('IAE');
title('IAE Comparison');
legend('PI', 'PID', 'Proposed(FOPID)');
grid on;
xlim([0 10]);

% ----------------- ISE Plot -----------------
subplot(3,1,2);
plot(t, ISE_PI, 'Color', color_PI, 'LineWidth', 1.8); hold on;
plot(t, ISE_PID, 'Color', color_PID, 'LineWidth', 1.8);
plot(t, ISE_FOPID, 'Color', color_FOPID, 'LineWidth', 1.8);
xlabel('Time (Sec)');
ylabel('ISE');
title('ISE Comparison');
legend('PI', 'PID', 'Proposed(FOPID)');
grid on;
xlim([0 10]);

% ----------------- ITAE Plot -----------------
subplot(3,1,3);
plot(t, ITAE_PI, 'Color', color_PI, 'LineWidth', 1.8); hold on;
plot(t, ITAE_PID, 'Color', color_PID, 'LineWidth', 1.8);
plot(t, ITAE_FOPID, 'Color', color_FOPID, 'LineWidth', 1.8);
xlabel('Time (Sec)');
ylabel('ITAE');
title('ITAE Comparison');
legend('PI', 'PID', 'Proposed(FOPID)');
grid on;
xlim([0 10]);


