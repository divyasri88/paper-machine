clc;
clear;
close all;

% Define Laplace variable
s = tf('s');

% Transfer Function 
num_gp = [-0.288 0.8825 0.5452];
den_gp = [1.247 5.365 4.39 1];
Gp = tf(num_gp, den_gp);

% FOPID Controller Parameters 
fopid_ALO_vals = [0.8324, 0.3885, 0.1027, 1.0729, 1.2156];
fopid_MFO_vals = [0.9431, 0.6028, 0.0891, 1.1382, 1.2645];
fopid_EHO_vals = [1.0635, 0.4912, 0.0803, 1.0274, 0.8427];
fopid_JSO_vals = [1.1847, 0.3276, 0.0415, 0.9183, 0.7295];
wL = 1e-3;
wH = 1e2;
N = 5;
C_FOPID_ALO = fopid_controller(fopid_ALO_vals, wL, wH, N);
C_FOPID_MFO = fopid_controller(fopid_MFO_vals, wL, wH, N);
C_FOPID_EHO = fopid_controller(fopid_EHO_vals, wL, wH, N);
C_FOPID_JSO = fopid_controller(fopid_JSO_vals, wL, wH, N);

% Complementary Sensitivity Functions: T = C(s)Gp(s) / (1 + C(s)Gp(s))
T_FOPID_ALO = feedback(C_FOPID_ALO * Gp, 1);
T_FOPID_MFO = feedback(C_FOPID_MFO * Gp, 1);
T_FOPID_EHO = feedback(C_FOPID_EHO * Gp, 1);
T_FOPID_JSO = feedback(C_FOPID_JSO * Gp, 1);

% Bode plot
w = logspace(-2, 2, 1000);

% Compute Bode magnitude for Complementary Sensitivity Functions
[magT_ALO, ~] = bode(T_FOPID_ALO, w);  magT_ALO = squeeze(magT_ALO);
[magT_MFO, ~] = bode(T_FOPID_MFO, w);  magT_MFO = squeeze(magT_MFO);
[magT_EHO, ~] = bode(T_FOPID_EHO, w);  magT_EHO = squeeze(magT_EHO);
[magT_JSO, ~] = bode(T_FOPID_JSO, w);  magT_JSO = squeeze(magT_JSO);

% Plot
figure;
semilogx(w, 20*log10(magT_ALO), 'g', ...
         w, 20*log10(magT_MFO), 'r', ...
         w, 20*log10(magT_EHO), 'm', ...
         w, 20*log10(magT_JSO), 'b', 'LineWidth', 1.5);
legend('ALO-FOPID', 'MFO-FOPID', 'EHO-FOPID', 'JSO-FOPID', 'Location', 'Best');
xlabel('Frequency (rad/s)');
ylabel('Magnitude (dB)');
title('Complementary Sensitivity Function - FOPID Controllers');
ylim([-40 10]); % Adjust Y-axis range as needed
grid on;

% ------------------------------ Functions ------------------------------
function C = fopid_controller(params, wL, wH, N)
    Kp = params(1);
    Ki = params(2);
    Kd = params(3);
    lambda = params(4);
    mu = params(5);
    s_lambda = oustaloup(wL, wH, N, -lambda);  % Integral
    s_mu = oustaloup(wL, wH, N, mu);           % Derivative
    C = Kp + Ki * s_lambda + Kd * s_mu;
end

function G = oustaloup(wL, wH, N, alpha)
    K = wH^alpha;
    zeta = zeros(1, 2*N+1);
    rho = zeros(1, 2*N+1);
    for n = -N:N
        wn = sqrt(wL * wH) * (wH/wL)^((n + 0.5)/(2*N + 1));
        zeta(n + N + 1) = wn;
        rho(n + N + 1) = wn;
    end
    num = K * poly(zeta);
    den = poly(rho);
    G = tf(num, den);
end

